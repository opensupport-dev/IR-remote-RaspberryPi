var classlirc_1_1client_1_1SetLogCommand =
[
    [ "__init__", "classlirc_1_1client_1_1SetLogCommand.html#ac9d91ca85d80dc6ed09e14655e853781", null ]
];