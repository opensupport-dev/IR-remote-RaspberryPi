var ciniparser_8c =
[
    [ "ASCIILINESZ", "group__ciniparser.html#gaeb84e295ec3307b215991d4bf88bceb7", null ],
    [ "INI_INVALID_KEY", "group__ciniparser.html#gafd7ba4a10fc951dcb65fa2b001afb7a4", null ],
    [ "line_status", "group__ciniparser.html#gadc101255f1686a23210fb9ea88394d46", null ],
    [ "_line_status_", "group__ciniparser.html#ga2fdd0675424601a39f3534cf0088822c", [
      [ "LINE_UNPROCESSED", "group__ciniparser.html#gga2fdd0675424601a39f3534cf0088822cae8deb35d61b666841f30be6b33dbb6e6", null ],
      [ "LINE_ERROR", "group__ciniparser.html#gga2fdd0675424601a39f3534cf0088822cacabc82d28b99b2752b44952d9f25cc12", null ],
      [ "LINE_EMPTY", "group__ciniparser.html#gga2fdd0675424601a39f3534cf0088822caf8bdc180e3ccc9b55f583e9b9357c666", null ],
      [ "LINE_COMMENT", "group__ciniparser.html#gga2fdd0675424601a39f3534cf0088822ca89af02a41ffc71bee75cc281c8f586a3", null ],
      [ "LINE_SECTION", "group__ciniparser.html#gga2fdd0675424601a39f3534cf0088822ca392ca597d41dd3dc49b4a54100b8197e", null ],
      [ "LINE_VALUE", "group__ciniparser.html#gga2fdd0675424601a39f3534cf0088822cad9299150994ee09dd387cb6566e4a63e", null ]
    ] ],
    [ "ciniparser_dump", "group__ciniparser.html#gac3baf2303bc7715836462364ad3d1b71", null ],
    [ "ciniparser_dump_ini", "group__ciniparser.html#gaedeba8efcca011ca841b7d27f892e930", null ],
    [ "ciniparser_find_entry", "group__ciniparser.html#gafeceb3aa96858ad6d94367e834a84d19", null ],
    [ "ciniparser_freedict", "group__ciniparser.html#gaddec45454d13abb8fc4a8da8dd4cc338", null ],
    [ "ciniparser_getboolean", "group__ciniparser.html#ga21a20d1db5df6cb8854829a9649d57eb", null ],
    [ "ciniparser_getdouble", "group__ciniparser.html#gab47e041735c05feab41bb03b2c2b09f7", null ],
    [ "ciniparser_getint", "group__ciniparser.html#ga494c830a31e50ba9daa03c5b3b596d1d", null ],
    [ "ciniparser_getnsec", "group__ciniparser.html#ga306ec559a5feef2a44712a16a72ba64b", null ],
    [ "ciniparser_getsecname", "group__ciniparser.html#ga57f6090b503edee285e7897b280ee6d0", null ],
    [ "ciniparser_getstring", "group__ciniparser.html#gaeb8a3530ebcbacf04b16a06c2353699a", null ],
    [ "ciniparser_load", "group__ciniparser.html#ga1e877c8cb81d953914b7f10030d84ccd", null ],
    [ "ciniparser_set", "group__ciniparser.html#ga169dabf5b0a86dc1f4bd01ba6d7e23ce", null ],
    [ "ciniparser_unset", "group__ciniparser.html#gad0046980ed3cbf9da80b4f47655d27d9", null ]
];