var classlirc_1_1client_1_1SendCommand =
[
    [ "__init__", "classlirc_1_1client_1_1SendCommand.html#a642359fc24d5c521ea68463fd01ebae0", null ]
];