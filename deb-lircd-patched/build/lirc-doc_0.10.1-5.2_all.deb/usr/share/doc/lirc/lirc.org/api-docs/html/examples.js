var examples =
[
    [ "drivers/default/Makefile", "drivers_2default_2Makefile-example.html", null ],
    [ "ircat.py", "ircat_8py-example.html", null ],
    [ "irexec.cpp", "irexec_8cpp-example.html", null ],
    [ "irsend.cpp", "irsend_8cpp-example.html", null ],
    [ "irw.py", "irw_8py-example.html", null ],
    [ "list-keys.py", "list-keys_8py-example.html", null ],
    [ "list-remotes.py", "list-remotes_8py-example.html", null ],
    [ "simulate.py", "simulate_8py-example.html", null ]
];