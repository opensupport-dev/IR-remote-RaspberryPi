var searchData=
[
  ['name',['name',['../structflaglist.html#a7759b95e8ccf9db09a3a3b839468be71',1,'flaglist::name()'],['../structdriver.html#a2d4bc5861fb0d7bb1684e22a16b7d414',1,'driver::name()'],['../structir__ncode.html#ac28e8133cbc7aa22dbbc8ef722883d2b',1,'ir_ncode::name()'],['../structir__remote.html#acd104de70d9169542de9c471befb0045',1,'ir_remote::name()']]],
  ['ncode',['ncode',['../structbutton__state.html#abcd54bc28722a363e84384100a35399a',1,'button_state']]],
  ['ncode_5fdup',['ncode_dup',['../group__driver__api.html#gac288bce2140d2066a3990a1b2e3317c5',1,'ncode_dup(struct ir_ncode *ncode):&#160;ir_remote.c'],['../group__driver__api.html#gac288bce2140d2066a3990a1b2e3317c5',1,'ncode_dup(struct ir_ncode *ncode):&#160;ir_remote.c']]],
  ['ncode_5ffree',['ncode_free',['../group__driver__api.html#ga4477860d1f604548e032694de8f69c16',1,'ncode_free(struct ir_ncode *ncode):&#160;ir_remote.c'],['../group__driver__api.html#ga4477860d1f604548e032694de8f69c16',1,'ncode_free(struct ir_ncode *ncode):&#160;ir_remote.c']]],
  ['needs_5ftoggle_5fmask',['needs_toggle_mask',['../irrecord_8c.html#a4333218734746cc10fc0ff718f939a1f',1,'irrecord.c']]],
  ['next',['next',['../structir__ncode.html#a0e80278912121f630d3b398959c4dad7',1,'ir_ncode::next()'],['../structlirc__cmd__ctx.html#ad3a65fb2292c86d2e304bc81ba00e8a5',1,'lirc_cmd_ctx::next()']]],
  ['next_5fncode',['next_ncode',['../structir__ncode.html#a0591a65926113978c7db2426c65d9f77',1,'ir_ncode']]],
  ['no_5ffoot_5frep',['NO_FOOT_REP',['../ir__remote__types_8h.html#a94aa4cc9b331962ec02258cc794077cc',1,'ir_remote_types.h']]],
  ['no_5fhead_5frep',['NO_HEAD_REP',['../ir__remote__types_8h.html#abf5d6878061b54bd7abcf78ba6336fd0',1,'ir_remote_types.h']]],
  ['note',['note',['../classlirc_1_1database_1_1Config.html#a422c5b90676cdf1df9e1de9dd8efc6e6',1,'lirc::database::Config']]]
];
