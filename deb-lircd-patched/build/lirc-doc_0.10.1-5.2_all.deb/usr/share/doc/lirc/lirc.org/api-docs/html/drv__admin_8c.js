var drv__admin_8c =
[
    [ "MAX_PLUGINS", "drv__admin_8c.html#a253adbfdf28c48f8e6cbe1e85b31e05a", null ],
    [ "for_each_driver", "drv__admin_8c.html#a20c8785b0c4a112a87b05eec158ecef7", null ],
    [ "for_each_plugin", "drv__admin_8c.html#aac333496b18370092de4b8a1efde53d5", null ],
    [ "hw_choose_driver", "drv__admin_8c.html#a1eaff4902d2d278d2d42e47e763c89da", null ],
    [ "hw_print_drivers", "drv__admin_8c.html#aa7842693457def5402214040a01004b1", null ],
    [ "drv", "drv__admin_8c.html#a18548a9bde23bdaa38bd8be5ab24428f", null ],
    [ "drv_null", "drv__admin_8c.html#a4812505d2b58c85f504503c9cbc3ef45", null ]
];