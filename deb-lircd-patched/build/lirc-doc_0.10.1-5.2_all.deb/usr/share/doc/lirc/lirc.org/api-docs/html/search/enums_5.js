var searchData=
[
  ['toggle_5fstatus',['toggle_status',['../irrecord_8h.html#a7774e877792a8850268ef906922799f3',1,'irrecord.h']]]
];
