var searchData=
[
  ['_5fdictionary_5f',['_dictionary_',['../struct__dictionary__.html',1,'']]],
  ['_5fstate',['_State',['../classlirc_1_1client_1_1__State.html',1,'lirc::client']]]
];
