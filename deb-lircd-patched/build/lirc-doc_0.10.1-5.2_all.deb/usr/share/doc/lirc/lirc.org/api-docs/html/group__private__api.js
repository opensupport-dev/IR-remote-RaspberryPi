var group__private__api =
[
    [ "ciniparser.h", "ciniparser_8h.html", null ],
    [ "dictionary.h", "dictionary_8h.html", null ],
    [ "driver.h", "driver_8h.html", null ],
    [ "drv_admin.h", "drv__admin_8h.html", null ],
    [ "dump_config.h", "dump__config_8h.html", null ],
    [ "input_map.h", "input__map_8h.html", null ],
    [ "ir_remote.h", "ir__remote_8h.html", null ],
    [ "ir_remote_types.h", "ir__remote__types_8h.html", null ],
    [ "ir_remote_types.h", "ir__remote__types_8h.html", null ],
    [ "lirc-utils.h", "lirc-utils_8h.html", null ],
    [ "lirc_config.h", "lirc__config_8h.html", null ],
    [ "lirc_log.h", "lirc__log_8h.html", null ],
    [ "lirc_options.h", "lirc__options_8h.html", null ],
    [ "release.h", "release_8h.html", null ],
    [ "drop_root_cli", "group__private__api.html#ga24f983a41e2fccf1c7ba3ee4d69559a4", null ],
    [ "drop_sudo_root", "group__private__api.html#ga08cad0a0a22fb34e70ef33be007e484d", null ],
    [ "free_config", "group__private__api.html#gaa55b7dcba60df4c178fd885eaf129288", null ],
    [ "read_config", "group__private__api.html#gaae645b840ccf7816a6dd37d53bc4325a", null ]
];