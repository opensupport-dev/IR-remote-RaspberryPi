var classlirc_1_1client_1_1RawConnection =
[
    [ "__init__", "classlirc_1_1client_1_1RawConnection.html#a8c13dc118fdc32890b21bd1e7387b96c", null ],
    [ "close", "classlirc_1_1client_1_1RawConnection.html#ae013019105f8fd0c933f188aa465ac49", null ],
    [ "fileno", "classlirc_1_1client_1_1RawConnection.html#a94fd44d2010ad66c67106dffb36a4137", null ],
    [ "has_data", "classlirc_1_1client_1_1RawConnection.html#a22de4788bd224f001b747be4b1a167df", null ],
    [ "readline", "classlirc_1_1client_1_1RawConnection.html#af36877b715f2448d3e416b3570b3c2e5", null ]
];