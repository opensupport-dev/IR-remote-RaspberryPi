var ir__remote_8c =
[
    [ "decode_all", "group__driver__api.html#gae334c37e486ce414abf272d4850df6c4", null ],
    [ "find_longest_match", "ir__remote_8c.html#a4f258aeecf1e6d52490d1337c14bfafd", null ],
    [ "get_code_by_name", "group__driver__api.html#gafaa7cb5587a3c58e3e825411b966738a", null ],
    [ "get_decoding", "group__driver__api.html#gaf2e0b982088d231116dea399afa8597f", null ],
    [ "get_filter_parameters", "group__driver__api.html#ga1a1b6c86d0309f25ab5806a5f861692c", null ],
    [ "get_frequency_range", "group__driver__api.html#ga19bab2135ca2b7f68dc0b2f8cde9863f", null ],
    [ "get_ir_remote", "group__driver__api.html#ga251129673cd73c5f869bb53c6c38a88f", null ],
    [ "ir_remote_init", "group__driver__api.html#ga8d5bc121b8582a690000bc8befe13080", null ],
    [ "is_in_remotes", "group__driver__api.html#gaadf09b8ef4b71be00f8e53a39f70d315", null ],
    [ "map_code", "group__driver__api.html#gabac8048f405d0a78fcc01fa9ef1132df", null ],
    [ "map_gap", "group__driver__api.html#gac691a06cc99d8c914e2c7451407f245a", null ],
    [ "ncode_dup", "group__driver__api.html#gac288bce2140d2066a3990a1b2e3317c5", null ],
    [ "ncode_free", "group__driver__api.html#ga4477860d1f604548e032694de8f69c16", null ],
    [ "send_ir_ncode", "group__driver__api.html#ga51d2eb6ccf92c9210c69cd727b712bae", null ],
    [ "write_message", "group__driver__api.html#ga04461705747fd8521d369ee96ed762fe", null ],
    [ "decoding", "ir__remote_8c.html#aae1e36a18695c7bc004436556ff3b53e", null ],
    [ "last_remote", "group__driver__api.html#ga474c489cabdaae4546ca0ac26ec9cd87", null ],
    [ "repeat_code", "group__driver__api.html#ga2da0e0383db556d0e1ba7261763815c5", null ],
    [ "repeat_remote", "group__driver__api.html#ga7bc28a85da7d0ccf4466708918f01dc4", null ]
];