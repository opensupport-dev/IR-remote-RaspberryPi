var searchData=
[
  ['rc6_5fmask',['rc6_mask',['../structir__remote.html#a2a6af729b770240668e5394962728af8',1,'ir_remote']]],
  ['readdata',['readdata',['../structdriver.html#a6dc74317e7f5fff8153be89153766865',1,'driver']]],
  ['rec_5ffunc',['rec_func',['../structdriver.html#a41e193204b057873b878b1979c309db8',1,'driver']]],
  ['rec_5fmode',['rec_mode',['../structdriver.html#af26686923a5a786e47b5c39f3fd25399',1,'driver']]],
  ['release_5fdetected',['release_detected',['../structir__remote.html#a783c26d5860269f673cb0b5506332560',1,'ir_remote']]],
  ['repeat_5fcode',['repeat_code',['../group__driver__api.html#ga2da0e0383db556d0e1ba7261763815c5',1,'repeat_code():&#160;ir_remote.c'],['../group__driver__api.html#ga2da0e0383db556d0e1ba7261763815c5',1,'repeat_code():&#160;ir_remote.c']]],
  ['repeat_5fflag',['repeat_flag',['../structdecode__ctx__t.html#a7c9bcadb5d59fb05fdad3a0cdd9b1106',1,'decode_ctx_t']]],
  ['repeat_5fgap',['repeat_gap',['../structir__remote.html#a021d2bb70e0e6d0b1edc2ecb5705d4e4',1,'ir_remote']]],
  ['repeat_5fmask',['repeat_mask',['../structir__remote.html#a47f22b4a2e69b0d90ae6ad61960076b3',1,'ir_remote']]],
  ['repeat_5fremote',['repeat_remote',['../group__driver__api.html#ga7bc28a85da7d0ccf4466708918f01dc4',1,'repeat_remote():&#160;ir_remote.c'],['../group__driver__api.html#ga7bc28a85da7d0ccf4466708918f01dc4',1,'repeat_remote():&#160;ir_remote.c']]],
  ['reply',['reply',['../structlirc__cmd__ctx.html#affb9a0be119594fb1ea49deffbf5647d',1,'lirc_cmd_ctx']]],
  ['reply_5fto_5fstdout',['reply_to_stdout',['../structlirc__cmd__ctx.html#ac9e5bcea4d878fcc1a4f9a2672fc200e',1,'lirc_cmd_ctx']]],
  ['resolution',['resolution',['../structdriver.html#a91eef0a66c9eb8ba1d3c8c9f69a1086b',1,'driver']]],
  ['result',['result',['../classlirc_1_1client_1_1Reply.html#a0843f89f72ab1325d81597e78b5ba851',1,'lirc::client::Reply']]]
];
