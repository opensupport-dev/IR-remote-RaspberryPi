var searchData=
[
  ['python_20configuration_20database',['python configuration database',['../group__database.html',1,'']]],
  ['python_20client_20bindings',['Python client bindings',['../group__python__bindings.html',1,'']]]
];
