var searchData=
[
  ['gap',['gap',['../structir__remote.html#abde525f609dea108baab4b690c2b94e4',1,'ir_remote']]],
  ['gap2',['gap2',['../structir__remote.html#a105c35a3ef1a43991857da3d3e62d0d0',1,'ir_remote']]]
];
