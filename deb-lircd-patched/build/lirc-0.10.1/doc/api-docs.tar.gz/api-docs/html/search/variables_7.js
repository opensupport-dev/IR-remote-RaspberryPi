var searchData=
[
  ['head',['head',['../structlirc__cmd__ctx.html#adebe3ef131145237834323c6258cf811',1,'lirc_cmd_ctx']]]
];
