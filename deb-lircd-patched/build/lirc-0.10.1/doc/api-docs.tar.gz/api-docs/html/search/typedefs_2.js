var searchData=
[
  ['ir_5fcode',['ir_code',['../ir__remote__types_8h.html#a4607c3797b0d3ac909185d2844030624',1,'ir_remote_types.h']]]
];
