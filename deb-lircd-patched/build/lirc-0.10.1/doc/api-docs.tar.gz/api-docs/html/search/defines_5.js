var searchData=
[
  ['max_5fplugins',['MAX_PLUGINS',['../drv__admin_8c.html#a253adbfdf28c48f8e6cbe1e85b31e05a',1,'MAX_PLUGINS():&#160;drv_admin.c'],['../lirc__config_8h.html#a253adbfdf28c48f8e6cbe1e85b31e05a',1,'MAX_PLUGINS():&#160;lirc_config.h']]]
];
