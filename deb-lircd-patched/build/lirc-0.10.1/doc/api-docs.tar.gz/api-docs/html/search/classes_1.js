var searchData=
[
  ['abstractconnection',['AbstractConnection',['../classlirc_1_1client_1_1AbstractConnection.html',1,'lirc::client']]],
  ['asyncconnection',['AsyncConnection',['../classlirc_1_1async__client_1_1AsyncConnection.html',1,'lirc::async_client']]]
];
