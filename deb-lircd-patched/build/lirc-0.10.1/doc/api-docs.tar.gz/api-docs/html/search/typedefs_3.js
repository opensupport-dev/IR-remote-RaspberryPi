var searchData=
[
  ['line_5fstatus',['line_status',['../group__ciniparser.html#gadc101255f1686a23210fb9ea88394d46',1,'ciniparser.c']]]
];
