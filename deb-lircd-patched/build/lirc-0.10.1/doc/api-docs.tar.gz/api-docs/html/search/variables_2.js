var searchData=
[
  ['close_5ffunc',['close_func',['../structdriver.html#aea9a20decd81cb165101823a40fd29af',1,'driver']]],
  ['code',['code',['../structir__ncode.html#a17ca9e939fd5742de3ed6e29bdc68e8d',1,'ir_ncode::code()'],['../structdecode__ctx__t.html#a1a206e5968a38e6e5286be41c037c30c',1,'decode_ctx_t::code()']]],
  ['code_5flength',['code_length',['../structdriver.html#a46c80e7c710d4222fa41cc6af819e066',1,'driver']]],
  ['config',['config',['../classlirc_1_1database_1_1Config.html#a3486cd23389279fbb80bb5c4d547eee7',1,'lirc::database::Config']]],
  ['count',['count',['../structlengths__state.html#a28c55c710a63705fc89a5a578010960a',1,'lengths_state']]],
  ['curr_5fdriver',['curr_driver',['../driver_8c.html#a656110ac202d464ae49251c9599baf66',1,'curr_driver():&#160;driver.c'],['../driver_8h.html#a656110ac202d464ae49251c9599baf66',1,'curr_driver():&#160;driver.c']]],
  ['current',['current',['../structir__ncode.html#a849807a18ac00c5d4228c2ebf5eb6519',1,'ir_ncode']]]
];
