var classlirc_1_1client_1_1IdentCommand =
[
    [ "__init__", "classlirc_1_1client_1_1IdentCommand.html#a61649f8ba4da7cf039dfee4aadedfd40", null ]
];