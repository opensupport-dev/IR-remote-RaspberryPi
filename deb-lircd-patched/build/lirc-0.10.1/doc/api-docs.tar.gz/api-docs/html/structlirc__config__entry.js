var structlirc__config__entry =
[
    [ "change_mode", "structlirc__config__entry.html#a7121651758cc4bcb330d52616714189f", null ],
    [ "code", "structlirc__config__entry.html#a2cfbf1e66ac69a5ef5a40081db33a051", null ],
    [ "config", "structlirc__config__entry.html#a0ef34631e46c8c4f3b0a01b2a3ceda2b", null ],
    [ "flags", "structlirc__config__entry.html#abe3b90e6deac69df0b795805d1434155", null ],
    [ "ign_first_events", "structlirc__config__entry.html#a1bec463e225aa3d85718d09728be4d6d", null ],
    [ "mode", "structlirc__config__entry.html#a2222a73e42be5170abb2504963b26988", null ],
    [ "next", "structlirc__config__entry.html#a6435e0f1db0f3ccf9b7618dc5c8a7a1e", null ],
    [ "next_code", "structlirc__config__entry.html#a2fc3805a9300ec32f259eac0d2b5039c", null ],
    [ "next_config", "structlirc__config__entry.html#a253887014e3584b489193b23146ef97d", null ],
    [ "prog", "structlirc__config__entry.html#afdfe6e301f0a008a811253d09b945449", null ],
    [ "rep", "structlirc__config__entry.html#ac19143e8a484da6b75fe2bb35cb9af04", null ],
    [ "rep_delay", "structlirc__config__entry.html#a3a4e24cad40066b41758a05505caca6b", null ]
];