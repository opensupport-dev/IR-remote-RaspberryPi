var structopts =
[
    [ "analyse", "structopts.html#adb140a98f8d7c171d915f25cba1405f3", null ],
    [ "backupfile", "structopts.html#acd64d8bfb185cb79c17d65e808282409", null ],
    [ "commandline", "structopts.html#a9a3aec38ebe5b230b49e0847637f1f95", null ],
    [ "device", "structopts.html#afdf03398a49e71c3f8ce9549a578a60d", null ],
    [ "disable_namespace", "structopts.html#aa5c6e1378a529cb8bfa437225f706c5f", null ],
    [ "driver", "structopts.html#a57c1f52e9140db0d9eef75329a421e77", null ],
    [ "dynamic_codes", "structopts.html#a2ef7fbda17c44ba1e118b03882ee8592", null ],
    [ "filename", "structopts.html#a9838b1fcb2e0648c3df17c864684b160", null ],
    [ "force", "structopts.html#aaa3464638bca660bd87f90afa13c8967", null ],
    [ "get_post", "structopts.html#abc0ad9b6b67926b66461e566243b443c", null ],
    [ "get_pre", "structopts.html#a53089aa30a231b801a5fb0961af751fd", null ],
    [ "invert", "structopts.html#a19b61fd6352f332c74880d385935b0be", null ],
    [ "list_namespace", "structopts.html#ab20a96a9b6ee0d4867856d8546d63ea7", null ],
    [ "loglevel", "structopts.html#ae0a4db12c42df2a0defa720b9e8bb61b", null ],
    [ "test", "structopts.html#a9ba0302586321f522372131959d9c0e8", null ],
    [ "tmpfile", "structopts.html#ac86acc9f0a9a5d71744b9589f692dc49", null ],
    [ "trail", "structopts.html#a22bf351f9ba4e68fd24a6ff51158ec48", null ],
    [ "update", "structopts.html#aaa56d698dc08d7106f48fe1d66be0e1a", null ],
    [ "using_template", "structopts.html#a74db0c5ee07f2e6ba5724392d97ace84", null ]
];